﻿using System.Collections.Generic;

namespace BurakOzcan.Models
{
    public class AllVM
    {
        public List<resim> resimler { get; set; }
        public List<ozgecmis> ozgecmisler { get; set; }
        public List<video> videolar { get; set; }
        public List<amac> amaclar { get; set; }

    }
}
