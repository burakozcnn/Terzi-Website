﻿namespace BurakOzcan.Models
{
    public class video
    {
        public int id { get; set; }
        public string adi { get; set; }
        public string link { get; set; }
    }
}
