﻿namespace BurakOzcan.Models
{
    public class ozgecmis
    {
        public int id { get; set; }
        public string yazi { get; set; }
    }
}
