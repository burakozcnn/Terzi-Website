﻿using System.Data.Entity;

namespace BurakOzcan.Models
{
    public class Context: DbContext
    {
        public Context() : base("Data Source=.;Initial Catalog=BurakOzcan;Integrated Security=True")
        {
        }
        public DbSet<ozgecmis> cv { get; set; }
        public DbSet<resim> resimlerim { get; set; }
        public DbSet<video> videolar { get; set; }
        public DbSet<proje> projelerim { get; set; }
        public DbSet<OnerileriniYaz> iletisim { get; set; }
        public DbSet<amac> amac { get; set; }

    }
}
