﻿using System;

namespace BurakOzcan.Models
{
    public class proje
    {
        public int id { get; set; }
        public string projeAdi { get; set; }
        public string projeAciklamasi { get; set; }
        public DateTime projeTarih { get; set; }
    }
}
