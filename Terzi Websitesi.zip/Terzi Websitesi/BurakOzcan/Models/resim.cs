﻿namespace BurakOzcan.Models
{
    public class resim
    {
        public int id { get; set; }
        public string resimyolu { get; set; }
    }
}
