﻿namespace BurakOzcan.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ikincimig : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.amacs",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        yazi = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.amacs");
        }
    }
}
