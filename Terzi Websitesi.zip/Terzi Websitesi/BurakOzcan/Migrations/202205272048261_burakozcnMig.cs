﻿namespace BurakOzcan.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class burakozcnMig : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ozgecmis",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        yazi = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.OnerileriniYazs",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        ad = c.String(),
                        soyad = c.String(),
                        email = c.String(),
                        numara = c.String(),
                        mesajiniz = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.projes",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        projeAdi = c.String(),
                        projeAciklamasi = c.String(),
                        projeTarih = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.resims",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        resimyolu = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.videos",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        adi = c.String(),
                        link = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.videos");
            DropTable("dbo.resims");
            DropTable("dbo.projes");
            DropTable("dbo.OnerileriniYazs");
            DropTable("dbo.ozgecmis");
        }
    }
}
