﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BurakOzcan.Models;

namespace BurakOzcan.Controllers
{
    public class UlasimController : Controller
    {

        private readonly Context db = new Context();
        public IActionResult Gorusme()
        {
            return View();
        }
        public IActionResult iletisimKaydet(OnerileriniYaz formVeri)
        {
            var EmailCTRL = db.iletisim.Where(x => x.email == formVeri.email).FirstOrDefault();
            if (EmailCTRL == null)
            {        
                if (ModelState.IsValid)
                {
                    db.iletisim.Add(formVeri);
                    db.SaveChanges();
                    TempData["sonuc"] = "Mesajınız İletilmiştir.";
                }
            }
            return RedirectToAction("Gorusme");
        }

    }
}
