﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BurakOzcan.Models;

namespace BurakOzcan.Controllers
{
    public class AnaSayfaController : Controller
    {
        private readonly Context db = new Context();
        public IActionResult Baslangic()
        {
            var resimler = db.resimlerim.ToList();
            var amac = db.amac.ToList();

            var Model = new AllVM()
            {
                resimler = resimler,
                amaclar = amac

            };
            return View(Model);
        }
    }
}
