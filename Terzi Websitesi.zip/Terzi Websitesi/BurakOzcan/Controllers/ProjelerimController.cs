﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BurakOzcan.Models;

namespace BurakOzcan.Controllers
{
    public class ProjelerimController : Controller
    {
        private readonly Context db = new Context();

        public IActionResult Proje()
        {

            return View(db.projelerim.ToList());
        }
    }
}
