﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BurakOzcan.Models;

namespace BurakOzcan.Controllers
{
    public class GalerimController : Controller
    {
        private readonly Context db = new Context();

        public IActionResult Medya()
        {
            var resimler = db.resimlerim.ToList();
            var videolar = db.videolar.ToList();

            var Model = new AllVM()
            {
                resimler = resimler,
                videolar = videolar

            };
            return View(Model);
        }
    }
}
