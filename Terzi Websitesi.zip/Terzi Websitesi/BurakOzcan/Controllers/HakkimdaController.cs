﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BurakOzcan.Models;

namespace BurakOzcan.Controllers
{
    public class HakkimdaController : Controller
    {
        private readonly Context db = new Context();

        public IActionResult HakSayfasi()
        {
            var ozgecmis = db.cv.ToList();
            var videolar = db.videolar.ToList();

            var Model = new AllVM()
            {
                ozgecmisler = ozgecmis,
                videolar = videolar

            };
            return View(Model);
        }
    }
}
